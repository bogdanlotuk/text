<div class="map">
	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11525.21043150068!2d-79.4742179!3d43.7665769!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xaa4761e71603b4fc!2sWindow%20Armour!5e0!3m2!1sen!2sua!4v1579466110925!5m2!1sen!2sua" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</div>