<div class="instagram_block">
	<div class="wrapper">
		<h4>FOLLOW US ON INSTAGRAM</h4>
		<div class="tc">
			<a class="link" href="#!" target="_blank">
				<img src="/img/instagram-c.svg" alt="instagram logo">
				@turfinc
			</a>
		</div>
		<div class="instagram_img_wrap">
			<img src="/img/instagram_bg.jpg" alt="">
		</div>
	</div>
</div>