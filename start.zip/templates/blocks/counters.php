<div class="counters">
	<div class="wrapper">
		<div class="counter_wrap">
			<div class="counter_item">
				<p class="number"><span class="counter">500,000</span>+</p>
				<p>SQUARE FEET OF GRASS SOLD</p>
			</div>
			<div class="counter_item">
				<p class="number"><span class="counter">6,000</span>+</p>
				<p>PROJECTS SUPPLIED</p>
			</div>
		</div>
	</div>
</div>