<div class="logos">
    <div class="tc">
	    <h4>Some Of Our Happy Clients:</h4>
    </div>
    <div class="logos_slider">
        <?php for($i = 1; $i < 6; $i++ ):?>
        <a href="#" class="image">
            <img src="/img/client_logo_<?=$i;?>.jpg" alt="">
        </a>
        <?php endfor;?>
        <?php for($i = 1; $i < 6; $i++ ):?>
            <a href="#" class="image">
                <img src="/img/client_logo_<?=$i;?>.jpg" alt="">
            </a>
        <?php endfor;?>
    </div>
</div>