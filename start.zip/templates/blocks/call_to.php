<div class="cta_small">
    <div class="wrapper">
		<div class="cta_small_wrap">
			<p>INTERESTED IN OUR PRODUCTS? LET’s CONNECT</p>
			<a href="/contact" class="button || black_2">CLICK HERE</a>
		</div>
    </div>
</div>